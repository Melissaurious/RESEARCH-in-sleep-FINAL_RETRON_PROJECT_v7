# SPIRE Retron Mining Pipeline

Computational pipeline for systematic discovery and novelty assessment of
retron reverse transcriptases (RTs) in prokaryotic metagenomes.

## Citation

If you use these scripts, please cite:

> Toro, N. (2026) Landscape of retron diversity across the SPIRE prokaryotic
> metagenome resource reveals candidate novel type XI-like lineages.
> *bioRxiv* 2026.05.14.725207.
> https://doi.org/10.64898/2026.05.14.725207

## Description

Python and Bash scripts implementing the pipeline used to systematically
identify, classify, and prioritize novel retron RT sequences across the
SPIRE prokaryotic metagenome resource (107,078 representative genomes,
Schmidt et al. 2024). The analysis yielded 1,286 SPIRE-native candidates
distributed across 28 classification groups, and identified two candidate
novel lineages — TXI_C2like and TXI_noncan_h — within RT clade 8.

## Script Overview

| Script | Purpose |
|--------|---------|
| `00_run_full_pipeline.sh` | Master pipeline wrapper — runs all steps sequentially |
| `01_extract_neighborhood.py` | Extract ±N-gene genomic neighbourhood for each RT locus |
| `02_hmm_calibrate_and_classify.py` | Calibrate type-specific HMM thresholds and classify candidates |
| `03_accessory_enrichment.py` | Fisher's exact test for accessory cluster enrichment (FDR BH) |
| `04_extract_flanking_upstream.py` | Extract upstream sequences for ncRNA analysis |
| `05_taxonomic_stats.py` | Chi-squared, Pearson residuals, Gini-Simpson index per group |
| `06_novelty_prioritization.py` | Score lineages across 5 criteria; assign novelty priority |
| `07_run_mlocarna_rscape.sh` | mLocARNA + R-scape de novo ncRNA discovery wrapper |

## Installation

```bash
# Python dependencies
pip install -r requirements.txt

# External tools required (see requirements.txt for URLs)
# HMMER v3.3, MAFFT v7, IQ-TREE2 v2.3.2, EPA-ng, Gappa,
# MMseqs2, Infernal v1.1.5, CMfinder v0.4,
# mLocARNA v2.0.1, R-scape v2.0.4, HHsuite v3
```

## Quick Start

```bash
# 1. Main pipeline (conda activate struct_annot)
bash 00_run_full_pipeline.sh

# 2. ncRNA discovery (conda activate mlocarna_env)
bash 07_run_mlocarna_rscape.sh \
  upstream_300bp.fasta outdir/ lineage_label

# 3. Individual steps
python3 03_accessory_enrichment.py \
  --membership accessory_cluster_membership.tsv \
  --master master_candidates_1286.tsv \
  --out enrichment_results.tsv

python3 05_taxonomic_stats.py \
  --master master_candidates_1286.tsv \
  --out_dir stats_output/
```

## Key Parameters

| Parameter | Value | Notes |
|-----------|-------|-------|
| General HMM threshold | 160 bits | Conservative; use 114 bits for divergent lineages |
| MMseqs2 clustering | 30% id, 80% cov | Accessory protein clusters |
| Fisher FDR threshold | < 0.05 | Benjamini-Hochberg correction |
| Enrichment OR threshold | > 2.0 | Minimum odds ratio for significance |
| mLocARNA input size | ≤ 40 seqs | Larger sets degrade alignment quality |
| R-scape significance | E < 0.05 | Covarying base pairs |
| ncRNA signal threshold | obs/exp > 1.1x | Genuine RNA structure signal |

## Dependencies

### Python packages
See `requirements.txt`

### External tools
| Tool | Version | Reference |
|------|---------|-----------|
| HMMER | 3.3 | Eddy (2011) *PLOS Comput. Biol.* |
| MAFFT | 7.490 | Katoh & Standley (2013) *Mol. Biol. Evol.* |
| IQ-TREE2 | 2.3.2 | Minh et al. (2020) *Mol. Biol. Evol.* |
| EPA-ng | latest | Barbera et al. (2019) *Syst. Biol.* |
| MMseqs2 | latest | Steinegger & Söding (2017) *Nat. Methods* |
| Infernal | 1.1.5 | Nawrocki & Eddy (2013) *Bioinformatics* |
| mLocARNA | 2.0.1 | Will et al. (2007) *PLOS Comput. Biol.* |
| R-scape | 2.0.4 | Rivas et al. (2017) *Nat. Methods* |
| HHsuite | 3 | Steinegger et al. (2019) *Nat. Methods* |

## Statistical Methods

- **Chi-squared test:** `scipy.stats.chi2_contingency` (Virtanen et al. 2020)
- **Pearson residuals:** (O-E)/√E; |residual| > 2 indicates notable association
- **Gini-Simpson index:** 1-D where D = Σpᵢ²; 0 = exclusive to one taxon
- **Fisher's exact test + FDR:** Benjamini & Hochberg (1995)
  doi:10.1111/j.2517-6161.1995.tb02031.x

## Related Resources

- **SPIRE database:** https://spire.embl.de (Schmidt et al. 2024, *NAR*)
- **Reference retron sequences:** Mestre et al. (2020) *NAR*, 48, 12632-12650
- **bioRxiv preprint:** https://doi.org/10.64898/2026.05.14.725207

## License

MIT License — see `LICENSE.txt`
