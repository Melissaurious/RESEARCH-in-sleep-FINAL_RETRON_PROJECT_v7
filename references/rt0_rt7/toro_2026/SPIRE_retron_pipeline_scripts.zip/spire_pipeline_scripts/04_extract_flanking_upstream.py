#!/usr/bin/env python3
"""
extract_flanking_upstream.py
-----------------------------
Extract upstream sequences for ncRNA discovery.
Supports:
  - Fixed upstream window (e.g. 270bp, 300bp, 600bp)
  - From annotated GenBank files (accurate RT ATG position)
  - Output: FASTA for CMfinder / mLocARNA input

Usage:
  python3 04_extract_flanking_upstream.py \
    --gbk flanking_2kb_annotated.gbk \
    --window 270 \
    --out upstream_270bp.fasta

  # Or from master + GFF directly:
  python3 04_extract_flanking_upstream.py \
    --master master_candidates_1286.tsv \
    --gff_dir /path/to/prodigal_gff/ \
    --contig_gff_map /tmp/contig_to_gff.tsv \
    --genome_fasta_dir /path/to/genomes/ \
    --window 270 \
    --out upstream_270bp.fasta
"""

import argparse
import os
import re
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
import pandas as pd

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--gbk', default=None,
                   help='Annotated GenBank file (preferred: accurate ATG positions)')
    p.add_argument('--master', default=None, help='Master candidates TSV')
    p.add_argument('--gff_dir', default=None)
    p.add_argument('--contig_gff_map', default=None)
    p.add_argument('--genome_fasta_dir', default=None)
    p.add_argument('--window', type=int, default=270,
                   help='Upstream window in bp (default: 270)')
    p.add_argument('--out', required=True, help='Output FASTA')
    p.add_argument('--label', default='upstream',
                   help='Label suffix for sequence IDs')
    p.add_argument('--filter_ids', default=None,
                   help='Optional: file with protein IDs to include (one per line)')
    return p.parse_args()

def extract_from_gbk(gbk_file, window, label):
    """
    Extract upstream sequences from annotated GenBank.
    Looks for CDS features labelled 'RT' or containing 'RT' in notes.
    """
    records = []
    for rec in SeqIO.parse(gbk_file, 'genbank'):
        # Find RT feature
        rt_feat = None
        for feat in rec.features:
            if feat.type != 'CDS':
                continue
            note = ' '.join(feat.qualifiers.get('note', []))
            if 'RT' in note or feat.qualifiers.get('gene', [''])[0].startswith('RT'):
                rt_feat = feat
                break

        if rt_feat is None:
            continue

        seq_len = len(rec.seq)
        strand = rt_feat.location.strand

        if strand == 1:
            rt_atg = int(rt_feat.location.start)
            up_start = max(0, rt_atg - window)
            up_seq = rec.seq[up_start:rt_atg]
        else:
            rt_atg = int(rt_feat.location.end)
            up_end = min(seq_len, rt_atg + window)
            up_seq = rec.seq[rt_atg:up_end].reverse_complement()

        if len(up_seq) < 50:
            continue

        new_rec = SeqRecord(
            up_seq,
            id=f"{rec.id}|{strand}|{label}_{window}bp",
            description=f"upstream_{window}bp_of_RT | {rec.description[:60]}"
        )
        records.append(new_rec)

    return records

def main():
    args = parse_args()

    # Optional filter list
    filter_ids = None
    if args.filter_ids:
        with open(args.filter_ids) as f:
            filter_ids = set(l.strip() for l in f if l.strip())
        print(f"Filtering to {len(filter_ids)} specified IDs")

    if args.gbk:
        print(f"Extracting from GenBank: {args.gbk}")
        records = extract_from_gbk(args.gbk, args.window, args.label)
    else:
        raise ValueError("Provide --gbk (GenBank mode). "
                         "Direct GFF mode not yet implemented in this version.")

    # Apply filter
    if filter_ids:
        pid_records = [r for r in records
                      if r.id.split('|')[0] in filter_ids]
        print(f"After filter: {len(pid_records)}/{len(records)}")
        records = pid_records

    SeqIO.write(records, args.out, 'fasta')
    lens = [len(r.seq) for r in records]
    print(f"\nSaved: {len(records)} sequences -> {args.out}")
    if lens:
        print(f"Lengths: min={min(lens)}, mean={sum(lens)//len(lens)}, max={max(lens)}")

if __name__ == '__main__':
    main()
