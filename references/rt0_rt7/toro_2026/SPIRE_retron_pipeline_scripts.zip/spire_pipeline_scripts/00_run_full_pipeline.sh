#!/usr/bin/env bash
# run_full_pipeline.sh
# --------------------
# Master pipeline script for SPIRE retron mining.
# Adapt paths and parameters for new lineage analysis (e.g. UG/abi).
#
# Usage: bash 00_run_full_pipeline.sh
#
# Prerequisites:
#   - SPIRE proteins indexed and available
#   - HMMER, MAFFT, IQ-TREE2, EPA-ng, MMseqs2, Infernal installed
#   - conda environments: base (HMMER etc.), mlocarna_env (mLocARNA, R-scape)

set -euo pipefail

# ============================================================
# CONFIGURATION — Adapt these paths for your analysis
# ============================================================
BASE="/home/ntoro/spire/retron_pipeline_v2"
SCRIPTS_DIR="$(dirname $0)"

# Input data
SPIRE_PROTEINS="${BASE}/spire_all_proteins.faa"
REFS_FASTA="${BASE}/hmm_rt/mestre_1928_refs.fasta"
CONTIG_GFF_MAP="/tmp/contig_to_gff.tsv"
GFF_DIR="/home/ntoro/spire/representative_genomes/prodigal_gff"

# HMMs
GENERAL_HMM="${BASE}/hmm_rt/general_retron_RT.hmm"
TYPE_SPECIFIC_HMM_DIR="${BASE}/hmm_rt/type_specific"

# New lineage (change for UG/abi analysis)
NEW_LINEAGE="ug_abi"          # Label for new lineage
NEW_LINEAGE_REFS=""           # Path to new lineage reference FASTA
                               # (leave empty to skip new HMM construction)

# Output directories
OUT_DIR="${BASE}/spire_search/classification/SPIRE_RESULTS_v1"
FLANKING_DIR="${BASE}/flanking_dna"
NCRNA_DIR="${BASE}/ncRNA_analysis"

THREADS=16
SCORE_THRESHOLD=160            # General screen threshold

# ============================================================
echo "=== SPIRE Retron Mining Pipeline ==="
echo "Base: $BASE"
echo "Threads: $THREADS"
echo ""

# ============================================================
# STEP 1: General HMM screening
# ============================================================
echo "--- STEP 1: General RT HMM screening ---"
mkdir -p "${OUT_DIR}/general_screen"

if [ ! -f "${OUT_DIR}/general_screen/general_screen.tbl" ]; then
    hmmsearch --cpu $THREADS \
      --tblout "${OUT_DIR}/general_screen/general_screen.tbl" \
      --noali \
      $GENERAL_HMM \
      $SPIRE_PROTEINS
    echo "General screen done."
else
    echo "General screen already done, skipping."
fi

# Filter by score threshold
python3 -c "
import sys
threshold = $SCORE_THRESHOLD
hits = []
with open('${OUT_DIR}/general_screen/general_screen.tbl') as f:
    for line in f:
        if line.startswith('#'): continue
        parts = line.split()
        if float(parts[5]) >= threshold:
            hits.append(parts[0])
print(f'Candidates >= {threshold} bits: {len(hits)}')
with open('${OUT_DIR}/general_screen/candidates_${SCORE_THRESHOLD}bit_ids.txt','w') as f:
    f.write('\n'.join(hits))
"

# ============================================================
# STEP 2: Optional — Build new lineage HMM
# ============================================================
if [ -n "${NEW_LINEAGE_REFS}" ] && [ -f "${NEW_LINEAGE_REFS}" ]; then
    echo ""
    echo "--- STEP 2: Building HMM for ${NEW_LINEAGE} ---"
    mafft --auto --reorder "${NEW_LINEAGE_REFS}" \
      > "${TYPE_SPECIFIC_HMM_DIR}/${NEW_LINEAGE}_aligned.fasta"
    hmmbuild "${TYPE_SPECIFIC_HMM_DIR}/${NEW_LINEAGE}.hmm" \
      "${TYPE_SPECIFIC_HMM_DIR}/${NEW_LINEAGE}_aligned.fasta"
    echo "New HMM: ${TYPE_SPECIFIC_HMM_DIR}/${NEW_LINEAGE}.hmm"
fi

# ============================================================
# STEP 3: Type-specific classification
# ============================================================
echo ""
echo "--- STEP 3: Type-specific HMM classification ---"
mkdir -p "${OUT_DIR}/type_specific_hits"

python3 "${SCRIPTS_DIR}/02_hmm_calibrate_and_classify.py" \
    --hmm_dir "${TYPE_SPECIFIC_HMM_DIR}" \
    --refs_fasta "${REFS_FASTA}" \
    --candidates_fasta "${SPIRE_PROTEINS}" \
    --out_thresholds "${OUT_DIR}/calibration/thresholds.tsv" \
    --out_classified "${OUT_DIR}/tables/master_candidates_classified.tsv" \
    --threads $THREADS

# ============================================================
# STEP 4: Filter SPIRE-native (exclude k* contigs)
# ============================================================
echo ""
echo "--- STEP 4: Genomic context filter ---"
python3 -c "
import pandas as pd
df = pd.read_csv('${OUT_DIR}/tables/master_candidates_classified.tsv', sep='\t')
spire = df[~df['protein_id'].str.contains('k141_|k119_')]
print(f'Total: {len(df)}, SPIRE-native: {len(spire)}, Excluded: {len(df)-len(spire)}')
spire.to_csv('${OUT_DIR}/tables/master_candidates_spire_native.tsv', sep='\t', index=False)
"

# ============================================================
# STEP 5: Genomic neighbourhood analysis
# ============================================================
echo ""
echo "--- STEP 5: Genomic neighbourhood extraction ---"
mkdir -p "${FLANKING_DIR}/neighbourhood"

python3 "${SCRIPTS_DIR}/01_extract_neighborhood.py" \
    --master "${OUT_DIR}/tables/master_candidates_spire_native.tsv" \
    --gff_dir "${GFF_DIR}" \
    --contig_gff_map "${CONTIG_GFF_MAP}" \
    --out_dir "${FLANKING_DIR}/neighbourhood" \
    --window_broad 5 \
    --window_tight 2

# MMseqs2 clustering of tight neighbours
mmseqs easy-cluster \
    "${FLANKING_DIR}/neighbourhood/neighborhood_pm2_proteins.fasta" \
    "${FLANKING_DIR}/neighbourhood/clusters/accessory_clusters" \
    "${FLANKING_DIR}/neighbourhood/clusters/tmp" \
    --min-seq-id 0.30 -c 0.80 --cov-mode 0 --threads $THREADS

# Pfam annotation
hmmscan --cpu $THREADS \
    --tblout "${FLANKING_DIR}/neighbourhood/pfam_hits.tbl" \
    "${BASE}/db/Pfam-A.hmm" \
    "${FLANKING_DIR}/neighbourhood/clusters/accessory_clusters_rep_seq.fasta"

# ============================================================
# STEP 6: Statistical analyses
# ============================================================
echo ""
echo "--- STEP 6: Statistical analyses ---"
mkdir -p "${OUT_DIR}/stats"

# Accessory enrichment
python3 "${SCRIPTS_DIR}/03_accessory_enrichment.py" \
    --membership "${OUT_DIR}/tables/accessory_cluster_membership_with_loci.tsv" \
    --master "${OUT_DIR}/tables/master_candidates_spire_native.tsv" \
    --out "${OUT_DIR}/stats/accessory_enrichment.tsv"

# Taxonomic/ecological stats
python3 "${SCRIPTS_DIR}/05_taxonomic_stats.py" \
    --master "${OUT_DIR}/tables/master_candidates_spire_native.tsv" \
    --out_dir "${OUT_DIR}/stats/taxonomic/"

# ============================================================
# STEP 7: Novelty prioritization
# ============================================================
echo ""
echo "--- STEP 7: Novelty prioritization ---"
python3 "${SCRIPTS_DIR}/06_novelty_prioritization.py" \
    --master "${OUT_DIR}/tables/master_candidates_spire_native.tsv" \
    --enrichment "${OUT_DIR}/stats/accessory_enrichment.tsv" \
    --residuals "${OUT_DIR}/stats/taxonomic/pearson_residuals_phylum.tsv" \
    --out "${OUT_DIR}/stats/novelty_scores.tsv"

echo ""
echo "=== Pipeline complete ==="
echo "Key output files:"
echo "  Master table: ${OUT_DIR}/tables/master_candidates_spire_native.tsv"
echo "  Enrichment:   ${OUT_DIR}/stats/accessory_enrichment.tsv"
echo "  Taxo stats:   ${OUT_DIR}/stats/taxonomic/"
echo "  Novelty:      ${OUT_DIR}/stats/novelty_scores.tsv"
echo ""
echo "Next: Run ncRNA discovery with 07_run_mlocarna_rscape.sh"
echo "      for candidate novel lineages."
