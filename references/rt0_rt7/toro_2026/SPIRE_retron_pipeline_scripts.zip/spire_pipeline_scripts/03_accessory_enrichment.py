#!/usr/bin/env python3
"""
accessory_enrichment.py
------------------------
Fisher's exact test for accessory cluster enrichment per retron group.
Computes OR and FDR-corrected p-values.

Usage:
  python3 03_accessory_enrichment.py \
    --membership accessory_cluster_membership_with_loci.tsv \
    --master master_candidates_1286.tsv \
    --out accessory_enrichment_results.tsv
"""

import argparse
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact
from statsmodels.stats.multitest import multipletests

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--membership', required=True,
                   help='Accessory cluster membership TSV '
                        '(cols: rt_protein, group, accessory_cluster_id, pfam_hit, ...)')
    p.add_argument('--master', required=True,
                   help='Master candidates TSV with group assignments')
    p.add_argument('--out', required=True, help='Output enrichment TSV')
    p.add_argument('--fdr_threshold', type=float, default=0.05)
    p.add_argument('--or_threshold', type=float, default=2.0)
    return p.parse_args()

def fisher_enrichment(membership_df, master_df):
    """
    For each (group, accessory_cluster) pair, compute Fisher's exact test.
    Contingency table:
        a = loci in group WITH cluster
        b = loci in group WITHOUT cluster
        c = loci in other groups WITH cluster
        d = loci in other groups WITHOUT cluster
    """
    groups = master_df['group'].unique()
    clusters = membership_df['accessory_cluster_id'].unique()

    # Total loci per group
    group_totals = master_df.groupby('group')['protein_id'].nunique()

    results = []
    for group in groups:
        n_group = group_totals.get(group, 0)
        n_other = len(master_df) - n_group

        group_loci = set(master_df[master_df['group'] == group]['protein_id'])

        for cluster in clusters:
            cluster_loci = set(membership_df[
                membership_df['accessory_cluster_id'] == cluster]['rt_protein'])

            a = len(group_loci & cluster_loci)          # group + cluster
            b = n_group - a                              # group, no cluster
            c = len(cluster_loci) - a                   # other + cluster
            d = n_other - c                              # other, no cluster

            if a == 0:
                continue  # Skip if not present in group

            _, pval = fisher_exact([[a, b], [c, d]])
            OR = (a * d) / (b * c) if (b * c) > 0 else np.inf

            # Get pfam annotation if available
            pfam = membership_df[
                membership_df['accessory_cluster_id'] == cluster
            ]['pfam_hit'].dropna().unique()
            pfam_str = ';'.join(pfam[:3]) if len(pfam) > 0 else ''

            results.append({
                'group': group,
                'accessory_cluster_id': cluster,
                'n_in_group': a,
                'n_group_total': n_group,
                'n_in_other': c,
                'n_other_total': n_other,
                'OR': round(OR, 2) if np.isfinite(OR) else 'Inf',
                'pval': pval,
                'pfam_hit': pfam_str,
            })

    df = pd.DataFrame(results)

    # FDR correction (Benjamini-Hochberg, 1995)
    # doi:10.1111/j.2517-6161.1995.tb02031.x
    _, padj, _, _ = multipletests(df['pval'], method='fdr_bh')
    df['FDR'] = padj

    # Mark significant
    df['OR_numeric'] = df['OR'].replace('Inf', np.inf).astype(float)
    df['significant'] = (df['FDR'] < 0.05) & (df['OR_numeric'] > 2.0)

    return df.sort_values(['group', 'FDR'])

def main():
    args = parse_args()

    membership = pd.read_csv(args.membership, sep='\t')
    master = pd.read_csv(args.master, sep='\t')

    print(f"Groups: {master['group'].nunique()}")
    print(f"Accessory clusters: {membership['accessory_cluster_id'].nunique()}")
    print(f"Total loci: {len(master)}")

    results = fisher_enrichment(membership, master)

    results.to_csv(args.out, sep='\t', index=False)
    print(f"\nResults saved: {args.out}")
    print(f"Total tests: {len(results)}")
    print(f"Significant (FDR<{args.fdr_threshold}, OR>{args.or_threshold}): "
          f"{results['significant'].sum()}")

    # Summary of top enrichments
    sig = results[results['significant']].copy()
    sig['OR_display'] = sig['OR'].astype(str)
    print("\nTop 10 enriched clusters:")
    print(sig.nsmallest(10, 'FDR')[
        ['group','accessory_cluster_id','n_in_group','OR','FDR','pfam_hit']
    ].to_string(index=False))

if __name__ == '__main__':
    main()
