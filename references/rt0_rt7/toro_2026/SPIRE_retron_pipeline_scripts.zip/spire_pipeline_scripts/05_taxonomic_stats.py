#!/usr/bin/env python3
"""
taxonomic_stats.py
------------------
Compute taxonomic and ecological statistics for retron groups:
  - Chi-squared test (group x phylum, group x biome)
  - Pearson standardized residuals
  - Gini-Simpson diversity index (1-D) per group
  - % host-associated per group

Output files:
  - taxo_stats_per_group.tsv     : per-group summary
  - pearson_residuals_phylum.tsv : residuals matrix (group x phylum)
  - pearson_residuals_biome.tsv  : residuals matrix (group x biome)

Usage:
  python3 05_taxonomic_stats.py \
    --master master_candidates_1286.tsv \
    --out_dir stats_output/
"""

import argparse
import os
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--master', required=True, help='Master candidates TSV')
    p.add_argument('--out_dir', required=True, help='Output directory')
    p.add_argument('--min_group_n', type=int, default=5,
                   help='Minimum loci per group for chi2 (default: 5)')
    p.add_argument('--min_cat_n', type=int, default=5,
                   help='Minimum loci per category for chi2 (default: 5)')
    return p.parse_args()

def gini_simpson(counts):
    """Compute Gini-Simpson diversity index (1-D) from counts."""
    total = counts.sum()
    if total == 0:
        return np.nan
    props = counts / total
    D = (props ** 2).sum()
    return 1 - D

def compute_group_stats(df):
    """Per-group taxonomic and ecological summary."""
    results = []
    for group, sub in df.groupby('group'):
        n = len(sub)
        phylum_counts = sub['phylum'].value_counts()
        biome_counts  = sub['biome_top'].value_counts()

        dom_phylum = phylum_counts.index[0] if len(phylum_counts) > 0 else 'NA'
        pct_dom    = phylum_counts.iloc[0] / n * 100 if len(phylum_counts) > 0 else 0
        gs         = gini_simpson(phylum_counts)
        pct_host   = (sub['biome_top'] == 'host-associated').sum() / n * 100

        results.append({
            'group': group,
            'n_total': n,
            'n_phyla': len(phylum_counts),
            'dominant_phylum': dom_phylum,
            'pct_dominant': round(pct_dom, 1),
            'gini_simpson_1minusD': round(gs, 3),
            'pct_host_associated': round(pct_host, 1),
            'dominant_biome': biome_counts.index[0] if len(biome_counts) > 0 else 'NA',
            'pct_dominant_biome': round(biome_counts.iloc[0]/n*100, 1)
                                  if len(biome_counts) > 0 else 0,
        })

    return pd.DataFrame(results).sort_values('n_total', ascending=False)

def compute_chi2_residuals(df, row_col, col_col, min_row_n, min_col_n):
    """
    Compute Pearson chi2 and standardized residuals.
    Returns: chi2_stat, p_value, dof, residuals_df
    """
    contingency = pd.crosstab(df[row_col], df[col_col])

    # Filter by minimum counts
    valid_rows = contingency[contingency.sum(axis=1) >= min_row_n].index
    valid_cols = contingency.columns[contingency.sum(axis=0) >= min_col_n]
    cont_f = contingency.loc[valid_rows, valid_cols]

    chi2, p, dof, expected = chi2_contingency(cont_f)
    residuals = (cont_f - expected) / np.sqrt(expected)

    return chi2, p, dof, residuals

def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    df = pd.read_csv(args.master, sep='\t')
    print(f"Loaded {len(df)} candidates, {df['group'].nunique()} groups")

    # Per-group stats
    print("\nComputing per-group statistics...")
    stats_df = compute_group_stats(df)
    stats_path = os.path.join(args.out_dir, 'taxo_stats_per_group.tsv')
    stats_df.to_csv(stats_path, sep='\t', index=False)
    print(stats_df.to_string(index=False))

    # Chi2: group x phylum
    print("\n=== Chi2: group x phylum ===")
    chi2_p, pval_p, dof_p, res_p = compute_chi2_residuals(
        df, 'group', 'phylum',
        args.min_group_n, args.min_cat_n)
    print(f"Chi2={chi2_p:.1f}, df={dof_p}, p={pval_p:.2e}")

    res_p.to_csv(os.path.join(args.out_dir, 'pearson_residuals_phylum.tsv'),
                 sep='\t')

    # Top enrichments
    print("\nTop Pearson residuals (phylum):")
    sig_rows = []
    for group in res_p.index:
        for col in res_p.columns:
            val = res_p.loc[group, col]
            if abs(val) > 2:
                sig_rows.append({
                    'group': group, 'phylum': col,
                    'residual': round(val, 2),
                    'direction': 'enriched' if val > 0 else 'depleted'
                })
    sig_df = pd.DataFrame(sig_rows);
    if not sig_df.empty: sig_df = sig_df.sort_values('residual', ascending=False)
    print(sig_df.to_string(index=False))
    sig_df.to_csv(os.path.join(args.out_dir, 'significant_phylum_residuals.tsv'),
                  sep='\t', index=False)

    # Chi2: group x biome
    print("\n=== Chi2: group x biome ===")
    chi2_b, pval_b, dof_b, res_b = compute_chi2_residuals(
        df, 'group', 'biome_top',
        args.min_group_n, args.min_cat_n)
    print(f"Chi2={chi2_b:.1f}, df={dof_b}, p={pval_b:.2e}")

    res_b.to_csv(os.path.join(args.out_dir, 'pearson_residuals_biome.tsv'),
                 sep='\t')

    print(f"\nAll results saved to: {args.out_dir}")
    print(f"Summary stats: {stats_path}")

if __name__ == '__main__':
    main()
