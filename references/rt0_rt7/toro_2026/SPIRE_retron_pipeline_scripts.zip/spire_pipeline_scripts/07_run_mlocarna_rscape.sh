#!/usr/bin/env bash
# run_mlocarna_rscape.sh
# ----------------------
# Wrapper for de novo ncRNA discovery pipeline:
#   1. mLocARNA structure-guided alignment
#   2. R-scape covariation analysis
#   3. Summarize results
#
# Prerequisites:
#   conda activate mlocarna_env
#   (contains mlocarna, rscape, r2r)
#
# Usage:
#   bash 07_run_mlocarna_rscape.sh \
#     upstream_300bp.fasta \
#     ncRNA_analysis/my_lineage/ \
#     my_lineage
#
# Arguments:
#   $1 = input FASTA (300bp upstream sequences, max ~40 seqs)
#   $2 = output directory
#   $3 = lineage label (for log messages)

set -euo pipefail

INPUT_FASTA="${1:?Usage: $0 input.fasta outdir/ lineage_label}"
OUT_DIR="${2:?Provide output directory}"
LABEL="${3:-lineage}"
THREADS="${4:-8}"

echo "=== mLocARNA + R-scape pipeline ==="
echo "Input:   $INPUT_FASTA"
echo "Output:  $OUT_DIR"
echo "Label:   $LABEL"
echo "Threads: $THREADS"
echo ""

N_SEQS=$(grep -c '^>' "$INPUT_FASTA" || true)
echo "Input sequences: $N_SEQS"

if [ "$N_SEQS" -gt 60 ]; then
    echo "WARNING: $N_SEQS sequences is high for mLocARNA (recommend <=40)."
    echo "         Consider filtering by motif presence before running."
    echo "         Continuing anyway..."
fi

mkdir -p "$OUT_DIR"

# Step 1: mLocARNA structure-guided alignment
echo ""
echo "--- Step 1: mLocARNA ---"
mlocarna \
    --stockholm \
    --threads "$THREADS" \
    --plfold-span 400 \
    --min-prob 0.03 \
    --indel -4 \
    --indel-open -400 \
    --max-diff 100 \
    --max-diff-am -60 \
    --alifold-cons \
    "$INPUT_FASTA" \
    --outdir "${OUT_DIR}/mlocarna/"

echo "mLocARNA done -> ${OUT_DIR}/mlocarna/results/result.stk"

# Check alignment quality
python3 -c "
import numpy as np
sto = '${OUT_DIR}/mlocarna/results/result.stk'
seqs = {}
ss = ''
with open(sto) as f:
    for line in f:
        line = line.rstrip()
        if line.startswith('#=GC SS_cons'):
            ss += line.split()[-1]
        elif not line.startswith('#') and not line.startswith('//') and line.strip():
            p = line.split()
            if len(p) == 2:
                if p[0] not in seqs: seqs[p[0]] = ''
                seqs[p[0]] += p[1]
if seqs:
    aln = np.array([list(v.upper()) for v in seqs.values()])
    gap_frac = np.mean(aln == '-')
    n_bps = ss.count('(') + ss.count('<')
    print(f'Sequences: {len(seqs)}, Columns: {aln.shape[1]}')
    print(f'Mean gap fraction: {gap_frac:.3f}')
    print(f'Predicted base pairs: {n_bps}')
    if gap_frac > 0.60:
        print('WARNING: High gap fraction (>60%) - alignment quality may be poor.')
        print('         Consider using fewer, more similar sequences.')
"

# Step 2: R-scape covariation analysis
echo ""
echo "--- Step 2: R-scape ---"
mkdir -p "${OUT_DIR}/rscape/"

rscape \
    --outdir "${OUT_DIR}/rscape/" \
    -E 0.05 \
    "${OUT_DIR}/mlocarna/results/result.stk"

echo "R-scape done -> ${OUT_DIR}/rscape/"

# Step 3: Parse R-scape results
echo ""
echo "--- Step 3: Summarizing covariation ---"
python3 -c "
import re, os, glob

rscape_dir = '${OUT_DIR}/rscape/'
out_files = glob.glob(os.path.join(rscape_dir, '*.cov'))
if not out_files:
    print('No .cov file found in R-scape output.')
    exit()

cov_file = out_files[0]
sig_pairs = []
with open(cov_file) as f:
    for line in f:
        if line.startswith('#') or not line.strip():
            continue
        parts = line.split()
        if len(parts) >= 7:
            try:
                e_val = float(parts[6])
                if e_val < 0.05:
                    sig_pairs.append({'i': parts[0], 'j': parts[1], 'E': e_val})
            except: pass

# Get total BPs from Stockholm
sto = '${OUT_DIR}/mlocarna/results/result.stk'
ss = ''
with open(sto) as f:
    for line in f:
        if line.startswith('#=GC SS_cons'):
            ss += line.split()[-1]
total_bps = ss.count('(') + ss.count('<')

print(f'Total predicted base pairs: {total_bps}')
print(f'Significantly covarying BPs (E<0.05): {len(sig_pairs)}')
if total_bps > 0:
    ratio_str = f'{len(sig_pairs)/total_bps*100:.0f}%'
    print(f'Fraction covarying: {ratio_str}')
print()

# Compare with expected (from R-scape output)
summary_files = glob.glob(os.path.join(rscape_dir, '*.surv'))
if summary_files:
    with open(summary_files[0]) as f:
        for line in f:
            if 'observed' in line.lower() or 'expected' in line.lower():
                print(line.rstrip())
"

echo ""
echo "=== Pipeline complete ==="
echo "Key outputs:"
echo "  Stockholm alignment: ${OUT_DIR}/mlocarna/results/result.stk"
echo "  R2R consensus:       ${OUT_DIR}/mlocarna/results/result.R2R.sto"
echo "  R-scape covariation: ${OUT_DIR}/rscape/*.cov"
echo ""
echo "Next steps:"
echo "  1. Generate R2R figure: r2r --GSC-weighted-consensus result.stk result.pdf"
echo "  2. If ratio >1.1x observed/expected -> genuine RNA structure signal"
echo "  3. Build CM: cmbuild model.cm result.stk && cmcalibrate model.cm"
