#!/usr/bin/env python3
"""
extract_neighborhood.py
-----------------------
Extract genomic neighbourhood (±N genes) for each retron RT locus.
Produces:
  - flanking_broad.tsv   : ±5 gene context
  - flanking_tight.tsv   : ±2 gene context (for accessory analysis)
  - neighborhood_pm2_proteins.fasta : protein sequences of tight neighbours

Usage:
  python3 01_extract_neighborhood.py \
    --master master_candidates_1286.tsv \
    --gff_dir /path/to/prodigal_gff/ \
    --contig_gff_map /tmp/contig_to_gff.tsv \
    --out_dir flanking_dna/
"""

import argparse
import os
import re
from pathlib import Path
from collections import defaultdict
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
import pandas as pd

def parse_args():
    p = argparse.ArgumentParser(description='Extract retron genomic neighbourhood')
    p.add_argument('--master', required=True, help='Master candidates TSV (1286)')
    p.add_argument('--gff_dir', required=True, help='Directory with Prodigal GFF files')
    p.add_argument('--contig_gff_map', required=True,
                   help='TSV: contig_id -> gff_filename')
    p.add_argument('--fasta_dir', default=None,
                   help='Directory with genome FASTA files (for protein extraction)')
    p.add_argument('--out_dir', required=True, help='Output directory')
    p.add_argument('--window_broad', type=int, default=5,
                   help='Broad neighbourhood window (default: 5)')
    p.add_argument('--window_tight', type=int, default=2,
                   help='Tight neighbourhood window (default: 2)')
    return p.parse_args()

def get_contig(protein_id):
    """Extract contig ID from protein ID (last underscore-delimited field = gene number)."""
    return '_'.join(protein_id.split('_')[:-1])

def get_gene_num(protein_id):
    """Extract gene number from protein ID."""
    return int(protein_id.split('_')[-1])

def load_contig_map(map_file):
    """Load contig -> GFF filename mapping."""
    cmap = {}
    with open(map_file) as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) == 2:
                cmap[parts[0]] = parts[1]
    print(f"Loaded {len(cmap):,} contig->GFF mappings")
    return cmap

def get_genes_on_contig(contig, gff_file, gff_dir):
    """Parse GFF and return all CDS genes on specified contig."""
    genes = []
    gff_path = os.path.join(gff_dir, gff_file)
    if not os.path.exists(gff_path):
        return genes
    with open(gff_path) as f:
        for line in f:
            if line.startswith('#'):
                continue
            parts = line.strip().split('\t')
            if len(parts) < 9 or parts[2] != 'CDS' or parts[0] != contig:
                continue
            m = re.search(r'_(\d+)(?:;|$)', parts[8])
            if not m:
                continue
            genes.append({
                'gnum':   int(m.group(1)),
                'start':  int(parts[3]) - 1,
                'end':    int(parts[4]),
                'strand': parts[6],
                'attrs':  parts[8]
            })
    return sorted(genes, key=lambda x: x['start'])

def extract_neighbourhood(protein_id, genes, window):
    """Extract ±window genes around the RT locus."""
    gene_num = get_gene_num(protein_id)
    rt_idx = next((i for i, g in enumerate(genes) if g['gnum'] == gene_num), None)
    if rt_idx is None:
        return None, []
    rt_gene = genes[rt_idx]
    start = max(0, rt_idx - window)
    end = min(len(genes), rt_idx + window + 1)
    neighbours = genes[start:end]
    return rt_gene, neighbours

def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    df = pd.read_csv(args.master, sep='\t')
    contig_map = load_contig_map(args.contig_gff_map)

    broad_rows = []
    tight_rows = []
    protein_seqs = []
    skipped = 0

    for _, row in df.iterrows():
        pid    = row['protein_id']
        contig = get_contig(pid)
        gff    = contig_map.get(contig)

        if not gff:
            skipped += 1
            continue

        genes = get_genes_on_contig(contig, gff, args.gff_dir)
        if not genes:
            skipped += 1
            continue

        rt_gene, broad_neighbours = extract_neighbourhood(pid, genes, args.window_broad)
        if rt_gene is None:
            skipped += 1
            continue

        _, tight_neighbours = extract_neighbourhood(pid, genes, args.window_tight)

        # Record broad neighbourhood
        for g in broad_neighbours:
            offset = g['gnum'] - get_gene_num(pid)
            broad_rows.append({
                'rt_protein': pid,
                'group': row.get('group', ''),
                'neighbour_gnum': g['gnum'],
                'offset': offset,
                'start': g['start'],
                'end': g['end'],
                'strand': g['strand'],
                'is_rt': offset == 0,
            })

        # Record tight neighbourhood (non-RT)
        for g in tight_neighbours:
            offset = g['gnum'] - get_gene_num(pid)
            if offset == 0:
                continue  # Skip RT itself
            tight_rows.append({
                'rt_protein': pid,
                'group': row.get('group', ''),
                'neighbour_gnum': g['gnum'],
                'offset': offset,
                'contig': contig,
            })

    # Save
    pd.DataFrame(broad_rows).to_csv(
        os.path.join(args.out_dir, 'flanking_broad.tsv'), sep='\t', index=False)
    pd.DataFrame(tight_rows).to_csv(
        os.path.join(args.out_dir, 'flanking_tight.tsv'), sep='\t', index=False)

    print(f"Processed: {len(df)-skipped}, Skipped: {skipped}")
    print(f"Broad neighbours: {len(broad_rows)}")
    print(f"Tight neighbours (non-RT): {len(tight_rows)}")
    print(f"Output: {args.out_dir}")

if __name__ == '__main__':
    main()
