#!/usr/bin/env python3
"""
novelty_prioritization.py
--------------------------
Score each retron lineage against 5 criteria and assign novelty priority.

Criteria (0-3 scale: absent/weak/moderate/strong):
  1. RT phylogenetic coherence
  2. Recurrent accessory architecture
  3. Confidence class support
  4. Taxonomic coherence (Gini-Simpson 1-D)
  5. Ecological coherence (Pearson residual)

Usage:
  python3 06_novelty_prioritization.py \
    --master master_candidates_1286.tsv \
    --enrichment accessory_enrichment_results.tsv \
    --residuals stats_output/pearson_residuals_phylum.tsv \
    --out novelty_scores.tsv
"""

import argparse
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--master', required=True)
    p.add_argument('--enrichment', required=True,
                   help='Accessory enrichment results TSV')
    p.add_argument('--residuals', required=True,
                   help='Pearson residuals TSV (group x phylum)')
    p.add_argument('--out', required=True)
    return p.parse_args()

def gini_simpson(df_group):
    counts = df_group['phylum'].value_counts()
    total = counts.sum()
    if total == 0: return np.nan
    props = counts / total
    return 1 - (props**2).sum()

def score_confidence(df_group):
    """Score confidence support (0-3)."""
    n = len(df_group)
    if n == 0: return 0
    pct_high = (df_group['hmm_confidence'] == 'high').sum() / n
    if pct_high >= 0.90: return 3
    if pct_high >= 0.70: return 2
    if pct_high >= 0.50: return 1
    return 0

def score_taxonomic(gs):
    """Score taxonomic coherence from Gini-Simpson (1-D).
    Low 1-D = high restriction = high score."""
    if np.isnan(gs): return 0
    if gs <= 0.15:   return 3   # Very restricted (e.g. clade2_Ec107like: 0.139)
    if gs <= 0.45:   return 2   # Moderately restricted
    if gs <= 0.65:   return 1   # Weakly restricted
    return 0                    # Cosmopolitan

def score_accessory(enrichment_df, group):
    """Score recurrent accessory architecture."""
    group_enrich = enrichment_df[
        (enrichment_df['group'] == group) &
        (enrichment_df['significant'] == True)
    ]
    n_sig = len(group_enrich)
    if n_sig == 0: return 0
    max_or = group_enrich['OR_numeric'].replace(np.inf, 999).max()
    if n_sig >= 2 and max_or > 10: return 3
    if n_sig >= 2 and max_or > 5:  return 2
    if n_sig >= 1:                 return 1
    return 0

def score_ecological(residuals_df, group):
    """Score ecological coherence from max absolute Pearson residual."""
    if group not in residuals_df.index: return 0
    max_res = residuals_df.loc[group].abs().max()
    if max_res >= 8:  return 3
    if max_res >= 5:  return 2
    if max_res >= 2:  return 1
    return 0

def assign_priority(scores):
    """Assign overall novelty priority from combined scores."""
    total = sum(scores.values())
    max_possible = 15  # 5 criteria * 3 max each
    # Also require strong phylogenetic coherence for high priority
    if scores['phylo'] == 3 and scores['accessory'] >= 2 and total >= 12:
        return 'high'
    if total >= 9:
        return 'medium'
    if total >= 4:
        return 'low'
    return 'none'

def main():
    args = parse_args()

    master = pd.read_csv(args.master, sep='\t')
    enrichment = pd.read_csv(args.enrichment, sep='\t')
    residuals = pd.read_csv(args.residuals, sep='\t', index_col=0)

    # Ensure OR_numeric column
    if 'OR_numeric' not in enrichment.columns:
        enrichment['OR_numeric'] = enrichment['OR'].replace(
            'Inf', np.inf).astype(float)
    if 'significant' not in enrichment.columns:
        enrichment['significant'] = (
            (enrichment['FDR'] < 0.05) &
            (enrichment['OR_numeric'] > 2.0))

    results = []

    for group, sub in master.groupby('group'):
        n = len(sub)
        gs = gini_simpson(sub)

        scores = {
            # Phylogenetic coherence: must be assessed manually from tree
            # Here we use a proxy: fraction of high-confidence as indicator
            'phylo':     score_confidence(sub),  # Proxy — update manually
            'accessory': score_accessory(enrichment, group),
            'confidence':score_confidence(sub),
            'taxonomic': score_taxonomic(gs),
            'ecological':score_ecological(residuals, group),
        }

        priority = assign_priority(scores)
        pct_high = (sub['hmm_confidence'] == 'high').sum() / n * 100

        results.append({
            'lineage': group,
            'n_total': n,
            'pct_high': round(pct_high, 1),
            'gini_simpson': round(gs, 3) if not np.isnan(gs) else 'NA',
            'score_phylo':      scores['phylo'],
            'score_accessory':  scores['accessory'],
            'score_confidence': scores['confidence'],
            'score_taxonomic':  scores['taxonomic'],
            'score_ecological': scores['ecological'],
            'total_score': sum(scores.values()),
            'novelty_priority': priority,
        })

    df_out = pd.DataFrame(results).sort_values('total_score', ascending=False)
    df_out.to_csv(args.out, sep='\t', index=False)

    print(df_out[['lineage','n_total','total_score','novelty_priority']].to_string(
        index=False))
    print(f"\nSaved: {args.out}")
    print("\nNOTE: 'score_phylo' is a proxy based on confidence tier.")
    print("      Update manually after inspecting EPA-ng placement tree.")

if __name__ == '__main__':
    main()
