#!/usr/bin/env python3
"""
hmm_calibrate_and_classify.py
------------------------------
Calibrate type-specific HMM thresholds (pos_min / neg_max)
and classify candidates by best-hit assignment.

Steps:
  1. For each HMM, compute pos_min (min self-hit) and neg_max (max cross-hit)
  2. threshold = (pos_min + neg_max) / 2
  3. For each candidate, assign to best-scoring HMM and classify confidence tier

Usage:
  python3 02_hmm_calibrate_and_classify.py \
    --hmm_dir hmm_rt/type_specific/ \
    --refs_fasta mestre_1928_refs.fasta \
    --candidates_fasta candidates_160bit.fasta \
    --out_thresholds hmm_rt/calibration/thresholds.tsv \
    --out_classified master_candidates_classified.tsv
"""

import argparse
import subprocess
import os
import re
import tempfile
import pandas as pd
from pathlib import Path

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--hmm_dir', required=True, help='Directory with type-specific HMMs')
    p.add_argument('--refs_fasta', required=True, help='All 1928 reference sequences FASTA')
    p.add_argument('--candidates_fasta', required=True, help='Candidate sequences FASTA')
    p.add_argument('--out_thresholds', required=True, help='Output thresholds TSV')
    p.add_argument('--out_classified', required=True, help='Output classified candidates TSV')
    p.add_argument('--threads', type=int, default=8)
    return p.parse_args()

def run_hmmsearch(hmm_file, fasta_file, threads=8):
    """Run hmmsearch and return {seq_id: score} dict."""
    with tempfile.NamedTemporaryFile(suffix='.tbl', delete=False) as tmp:
        tbl_path = tmp.name
    cmd = ['hmmsearch', f'--cpu {threads}',
           '--tblout', tbl_path, '--noali',
           hmm_file, fasta_file]
    subprocess.run(' '.join(cmd), shell=True, capture_output=True)
    scores = {}
    with open(tbl_path) as f:
        for line in f:
            if line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) >= 6:
                scores[parts[0]] = float(parts[5])
    os.unlink(tbl_path)
    return scores

def get_group_refs(refs_fasta, group_name):
    """Extract references belonging to a specific group from FASTA."""
    seqs = []
    from Bio import SeqIO
    for rec in SeqIO.parse(refs_fasta, 'fasta'):
        if rec.id.startswith(f'{group_name}|'):
            seqs.append(rec)
    return seqs

def calibrate_thresholds(hmm_dir, refs_fasta, threads):
    """Compute pos_min and neg_max for each HMM."""
    hmm_files = sorted(Path(hmm_dir).glob('*.hmm'))
    thresholds = []

    for hmm_file in hmm_files:
        group = hmm_file.stem
        print(f"Calibrating {group}...")

        # Self-hits (pos_min)
        self_scores = run_hmmsearch(str(hmm_file), refs_fasta, threads)
        self_scores_group = {k: v for k, v in self_scores.items()
                            if k.startswith(f'{group}|')}
        pos_min = min(self_scores_group.values()) if self_scores_group else 0

        # Cross-hits (neg_max)
        other_scores = {k: v for k, v in self_scores.items()
                       if not k.startswith(f'{group}|')}
        neg_max = max(other_scores.values()) if other_scores else 0

        threshold = (pos_min + neg_max) / 2

        thresholds.append({
            'group': group,
            'pos_min': round(pos_min, 1),
            'neg_max': round(neg_max, 1),
            'threshold': round(threshold, 1),
            'n_self_refs': len(self_scores_group),
        })
        print(f"  pos_min={pos_min:.1f}, neg_max={neg_max:.1f}, "
              f"threshold={threshold:.1f}")

    return pd.DataFrame(thresholds)

def classify_candidates(hmm_dir, candidates_fasta, thresholds_df, threads):
    """Classify each candidate to best-scoring HMM."""
    hmm_files = sorted(Path(hmm_dir).glob('*.hmm'))
    all_scores = {}  # {candidate_id: {group: score}}

    for hmm_file in hmm_files:
        group = hmm_file.stem
        scores = run_hmmsearch(str(hmm_file), candidates_fasta, threads)
        for seq_id, score in scores.items():
            if seq_id not in all_scores:
                all_scores[seq_id] = {}
            all_scores[seq_id][group] = score

    # Assign best hit and confidence tier
    threshold_map = dict(zip(thresholds_df['group'],
                             thresholds_df['threshold']))
    records = []
    for seq_id, group_scores in all_scores.items():
        if not group_scores:
            continue
        best_group = max(group_scores, key=group_scores.get)
        best_score = group_scores[best_group]
        thresh = threshold_map.get(best_group, 160)

        if best_score >= thresh:
            confidence = 'high'
        elif best_score >= 160:
            confidence = 'low'
        else:
            confidence = 'borderline'

        records.append({
            'protein_id': seq_id,
            'group': best_group,
            'score': round(best_score, 2),
            'threshold': round(thresh, 1),
            'hmm_confidence': confidence,
        })

    return pd.DataFrame(records)

def main():
    args = parse_args()
    os.makedirs(os.path.dirname(args.out_thresholds), exist_ok=True)

    print("=== Step 1: Calibrating HMM thresholds ===")
    thresholds_df = calibrate_thresholds(args.hmm_dir, args.refs_fasta, args.threads)
    thresholds_df.to_csv(args.out_thresholds, sep='\t', index=False)
    print(f"Thresholds saved: {args.out_thresholds}")
    print(thresholds_df.to_string(index=False))

    print("\n=== Step 2: Classifying candidates ===")
    classified_df = classify_candidates(args.hmm_dir, args.candidates_fasta,
                                        thresholds_df, args.threads)
    classified_df.to_csv(args.out_classified, sep='\t', index=False)
    print(f"Classified {len(classified_df)} candidates -> {args.out_classified}")
    print(classified_df['hmm_confidence'].value_counts().to_string())

if __name__ == '__main__':
    main()
